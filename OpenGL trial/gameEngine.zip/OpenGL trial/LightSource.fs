#version 410 core

out vec4 frag;

void main(){
    frag = vec4(1.0);
}
